Allows your phone to charge up to a user-selected battery % then stop charging until the battery has dropped to a second user-defined battery percentage. At this point it will start charging again, thus preventing undue stress on the battery as it is kept all day at 100%.            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。